let students = [
    {regno:'2021ICT114',name:'Sewmini',age:23,course:'IT',gender:'female'},
    {regno:'2021ICT2',name:'Gayan',age:22,course:'IT',gender:'male'},
    {regno:'2021ICT3',name:'Kalani',age:20,course:'IT',gender:'female'},
    {regno:'2021ICT116',name:'Nihal',age:21,course:'IT',gender:'male'},
    {regno:'2021ICT5',name:'Sithum',age:22,course:'IT',gender:'male'},
    {regno:'2021ICT7',name:'Amala',age:23,course:'IT',gender:'female'}
    ];

    module.exports=students;